package Assesment1;

public class SimpleSum {

	public static void main(String[] args) {

		int A=5;
		int B=4;
		int C=2;
		int sum=0;
		
		sum=A+B+C;
		System.out.println(sum);
		
	}

}
