package Assesment1;

public class ShinchanKazama {

	public static void main(String[] args) {

		int a=9;
		int b=1;
		int s=2;
		
		int dist=a-b;
		int time=dist/s;
		
		System.out.println(time);
		
	}

}
