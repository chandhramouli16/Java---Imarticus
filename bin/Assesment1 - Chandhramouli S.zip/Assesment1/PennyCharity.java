package Assesment1;

public class PennyCharity {

	public static void main(String[] args) {

		int N=6; 
		int M=20;
		
		if((M/N)>0) {
			System.out.println(M/N);
		}
		else
			System.out.println(-1);
		
	}

}
